

<div id="breadcrumb">
	<nav aria-label="breadcrumb">
		  <ol class="breadcrumb">
		   <li class="breadcrumb-item font-weight-bold m-t-2 fs-18" aria-current="page"><?php echo $crumb ?></li>
		   		<span class="float-right"><a id="go-back">
		    	<i class="fas fa-arrow-left m-t-5 fs-22" style="color: #212529"></i></a></span>
		  </ol>
	</nav>
</div>